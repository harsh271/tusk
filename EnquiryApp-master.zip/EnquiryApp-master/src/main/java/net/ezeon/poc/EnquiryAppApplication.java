package net.ezeon.poc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnquiryAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnquiryAppApplication.class, args);
	}

}
