# EnquiryApp
Spring Data JPA Project Work - Beginner To Expert Level

PURPOSE:
We developed this project to learn Spring Data JPA for Production Ready Project. Suitable for Beginner to Expert Java Spring Developers.

PROJECT WORK - ENQUIRY APP:
The purpose of this project work is to learn step by step development using Spring Data JPA Project. 
This video series will cover best practices of JPA Hibernate and related tools. 
Also it will everything thats necessary for production grade application. 
The complete video series is available in my YouTube Channel.

https://www.youtube.com/watch?v=xnQXpV7TaI8&list=PLLGI5phu9E45dpO83OlMfUmGm0hKLuPGa

WHAT IS SPRING DATA PROJECT:
Spring Data’s mission is to provide a familiar and consistent, Spring-based programming model for data access while still retaining the special traits of the underlying data store.

FEATURES:
Add Enquiry, List Enquiry, Add Institute, List Institute, Manage Enquiry Sources, Manage Courses and Necessary Reports and Reports.  

TECHNOLOGY USED:
Java 8, Spring Boot, Spring Data JPA, MySQL Database, NetBeans IDE, Hibernate JPA Implementation, Maven, MySQL Workbench, JSON, jQuery AJAX.
